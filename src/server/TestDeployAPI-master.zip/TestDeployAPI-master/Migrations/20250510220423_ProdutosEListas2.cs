﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TestDeployAPI.Migrations
{
    /// <inheritdoc />
    public partial class ProdutosEListas2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ListaCompras_Usuarios_UsuariosId",
                table: "ListaCompras");

            migrationBuilder.DropIndex(
                name: "IX_ListaCompras_UsuariosId",
                table: "ListaCompras");

            migrationBuilder.DropColumn(
                name: "UsuariosId",
                table: "ListaCompras");

            migrationBuilder.RenameColumn(
                name: "IdUsuarios",
                table: "ListaCompras",
                newName: "IdUsuario");

            migrationBuilder.CreateIndex(
                name: "IX_ListaCompras_IdUsuario",
                table: "ListaCompras",
                column: "IdUsuario");

            migrationBuilder.AddForeignKey(
                name: "FK_ListaCompras_Usuarios_IdUsuario",
                table: "ListaCompras",
                column: "IdUsuario",
                principalTable: "Usuarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ListaCompras_Usuarios_IdUsuario",
                table: "ListaCompras");

            migrationBuilder.DropIndex(
                name: "IX_ListaCompras_IdUsuario",
                table: "ListaCompras");

            migrationBuilder.RenameColumn(
                name: "IdUsuario",
                table: "ListaCompras",
                newName: "IdUsuarios");

            migrationBuilder.AddColumn<int>(
                name: "UsuariosId",
                table: "ListaCompras",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ListaCompras_UsuariosId",
                table: "ListaCompras",
                column: "UsuariosId");

            migrationBuilder.AddForeignKey(
                name: "FK_ListaCompras_Usuarios_UsuariosId",
                table: "ListaCompras",
                column: "UsuariosId",
                principalTable: "Usuarios",
                principalColumn: "Id");
        }
    }
}
