﻿using Microsoft.EntityFrameworkCore;

namespace TestDeployAPI.Model
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {
        }

        public DbSet<Usuarios> Usuarios { get; set; }

        public DbSet<ListaCompras> ListaCompras { get; set; }

        public DbSet<Produto> Produtos { get; set; }

    }
}
