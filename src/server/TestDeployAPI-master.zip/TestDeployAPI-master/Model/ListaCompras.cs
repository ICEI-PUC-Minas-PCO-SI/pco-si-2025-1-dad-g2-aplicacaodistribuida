﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace TestDeployAPI.Model
{
    [Table("ListaCompras")]
    [Index(nameof(Codigo), IsUnique = true)] // Essa anottation ajuda com a busca por código na performance
    public class ListaCompras
    {
        [Key]
        public int Id { get; set; }

        public string Codigo { get; set; }

        public string Nome { get; set; }
        public string Descricao { get; set; }

        public int IdUsuario { get; set; }

        [ForeignKey("IdUsuario")]
        public Usuarios Usuario { get; set; }

        public ICollection<Produto> Produtos { get; set; }
    }
}
