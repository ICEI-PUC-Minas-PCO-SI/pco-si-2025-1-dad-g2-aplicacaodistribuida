﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace TestDeployAPI.Model
{
    [Table("Produto")]
    public class Produto
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Nome { get; set; }

        [Required]
        public string Categoria { get; set; }

        [DefaultValue(0.0f)]
        public float Quantidade { get; set; }

        [DefaultValue(0.0f)]
        public float Valor { get; set; }

        public string Medida { get; set; }

        public string LocalSugerido { get; set; }

        public bool FlagComprado { get; set; }
        public int IdListaCompras { get; set; }

        [ForeignKey("IdListaCompras")]
        public ListaCompras ListaCompras { get; set; }

    }
}
