﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace TestDeployAPI.Model
{
    [Table("Usuarios")]
    public class Usuarios
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo Email obrigatório")]
        [EmailAddress(ErrorMessage = "Email inválido")]
        public string Email { get; set; }

        public string Nome { get; set; }

        [Required(ErrorMessage = "Campo Senha obrigatório")]
        public string Senha { get; set; }

        public ICollection<ListaCompras> ListaCompras { get; set; }
    }
}
