﻿using Microsoft.EntityFrameworkCore;
using TestDeployAPI.Model;

namespace TestDeployAPI.Services
{
    public class ListaComprasService
    {
        public static string GenerateUniqueCode(AppDBContext appDBContext)
        {
            const string caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            string codigo;
            var random = new Random();

            do
            {
                codigo = new string(Enumerable.Range(0, 6)
                    .Select(_ => caracteres[random.Next(caracteres.Length)])
                    .ToArray());
            }
            while (appDBContext.ListaCompras.Any(l => l.Codigo == codigo));

            return codigo;
        }
    }
}
