﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using TestDeployAPI.Model;

namespace TestDeployAPI.Services
{
    public static class UsuariosService
    {

        public static string RegisterUser(AppDBContext appDBContext, Usuarios usuario)
        {

            if (usuario.Senha.Length < 6)
                return "A senha deve ter ao menos 6 caracteres";

            if (appDBContext.Usuarios.Any(u => u.Email == usuario.Email))
                return "Email já cadastrado";

            PasswordHasher<Usuarios> _passwordHasher = new PasswordHasher<Usuarios>();

            usuario.Id = 0; // ID is auto-incremented by the database

            usuario.Senha = _passwordHasher.HashPassword(usuario, usuario.Senha);

            appDBContext.Usuarios.Add(usuario);

            try
            {
                appDBContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                Console.WriteLine(ex.InnerException?.Message);
                return ex.Message;
            }

            return string.Empty;
        }

        public static Usuarios GetUserFromEmailAndPassword(AppDBContext appDBContext, string email, string senha) {

            PasswordHasher<Usuarios> _passwordHasher = new PasswordHasher<Usuarios>();

            Usuarios usuarios = appDBContext.Usuarios.FirstOrDefault(u => u.Email == email);

            if (usuarios == null)
                return null;

            var result = _passwordHasher.VerifyHashedPassword(usuarios, usuarios.Senha, senha);

            return (result == PasswordVerificationResult.Success ? usuarios : null);
        }
    }
}
