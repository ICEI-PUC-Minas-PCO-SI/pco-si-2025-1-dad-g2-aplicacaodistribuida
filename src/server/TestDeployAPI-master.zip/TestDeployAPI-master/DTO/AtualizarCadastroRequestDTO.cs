﻿namespace TestDeployAPI.DTO
{
    public class AtualizarCadastroRequestDTO
    {
        public string Email { get; set; }
        public string Nome { get; set; }

        public AtualizarCadastroRequestDTO(string nome, string email)
        {
            Nome = nome;
            Email = email;
        }
    }
}
