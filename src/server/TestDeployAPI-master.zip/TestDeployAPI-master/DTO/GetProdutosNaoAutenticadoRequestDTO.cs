﻿namespace TestDeployAPI.DTO
{
    public class GetProdutosNaoAutenticadoRequestDTO
    {
        public string CodigoLista { get; set; }
    }
}
