﻿namespace TestDeployAPI.DTO
{
    public class CriarListaComprasRequestDTO
    {
        public string Nome { get; set; }
        public string Descricao { get; set; }

        public CriarListaComprasRequestDTO(string nome, string descricao)
        {
            Nome = nome;
            Descricao = descricao;
        }
    }
}
