﻿namespace TestDeployAPI.DTO
{
    public class CriarProdutoResponseDTO
    {
        public CriarProdutoResponseDTO(string codigoLista, int idProduto)
        {
            CodigoLista = codigoLista;
            IdProduto = idProduto;
        }
        public string CodigoLista { get; set; }
        public int IdProduto { get; set; }
    }
}
