﻿namespace TestDeployAPI.DTO
{
    public class AtualizarProdutoRequestDTO
    {
        public string CodigoLista { get; set; }
        public int IdProduto { get; set; }

        public string Nome { get; set; }

        public string Categoria { get; set; }

        public float Quantidade { get; set; }

        public float Valor { get; set; }

        public string Medida { get; set; }

        public string LocalSugerido { get; set; }

        public bool Comprado { get; set; }
    }
}
