﻿namespace TestDeployAPI.DTO
{
    public class AtualizarFlagProdutoRequestDTO
    {
        public string CodigoLista { get; set; }
        public int IdProduto { get; set; }

        public bool Comprado { get; set; }
    }
}
