﻿namespace TestDeployAPI.DTO
{
    public class DeletarListaComprasRequestDTO
    {
        public string Codigo { get; set; }
    }
}
