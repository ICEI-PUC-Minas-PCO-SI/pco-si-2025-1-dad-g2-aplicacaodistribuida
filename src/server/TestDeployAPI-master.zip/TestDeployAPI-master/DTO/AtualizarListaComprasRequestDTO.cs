﻿namespace TestDeployAPI.DTO
{
    public class AtualizarListaComprasRequestDTO
    {
        public string Codigo { get; set; }
        public string Nome { get; set; }

        public string Descricao { get; set; }
       
    }
}
