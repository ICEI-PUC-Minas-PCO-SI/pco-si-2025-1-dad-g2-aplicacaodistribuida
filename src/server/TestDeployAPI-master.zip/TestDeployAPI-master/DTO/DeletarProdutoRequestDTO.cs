﻿namespace TestDeployAPI.DTO
{
    public class DeletarProdutoRequestDTO
    {
        public string CodigoLista { get; set; }

        public int IdProduto { get; set; }
    }
}