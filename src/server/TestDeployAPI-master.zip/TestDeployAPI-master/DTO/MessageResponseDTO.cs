﻿namespace TestDeployAPI.DTO
{
    public class MessageResponseDTO
    {
        public string Message { get; set; }
        public MessageResponseDTO(string message)
        {
            Message = message;
        }
    }
}
