﻿namespace TestDeployAPI.DTO
{
    public class LoginRequestDTO
    {
        public string Email { get; set; }
        public string Senha { get; set; }

    }
}
