﻿using TestDeployAPI.Model;

namespace TestDeployAPI.DTO
{
    public class GetProdutosFromListRequestDTO
    {
        public string codigoLista { get; set; }

    }
}
