﻿using TestDeployAPI.Model;

namespace TestDeployAPI.DTO
{
    public class ListaComprasResponseDTO
    {
        public ListaComprasResponseDTO(ListaCompras listaCompras)
        {
            Codigo = listaCompras.Codigo;
            Nome = listaCompras.Nome;
            Descricao = listaCompras.Descricao;
        }

        public static ICollection<ListaComprasResponseDTO> FromModelCollection(ICollection<ListaCompras> listaCompras)
        {
            return listaCompras.Select(l => new ListaComprasResponseDTO(l)).ToList();
        }

        public string Codigo { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
    }
}
