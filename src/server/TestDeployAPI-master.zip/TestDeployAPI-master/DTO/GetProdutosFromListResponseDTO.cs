﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using TestDeployAPI.Model;

namespace TestDeployAPI.DTO
{
    public class GetProdutosFromListResponseDTO
    {

        public static ICollection<GetProdutosFromListResponseDTO> GetFromProdutosCollection(ICollection<Produto> produtos)
        {
            return produtos.Select(p => new GetProdutosFromListResponseDTO
            {
                CodigoLista = p.ListaCompras.Codigo,
                Id = p.Id,
                Nome = p.Nome,
                Categoria = p.Categoria,
                Quantidade = p.Quantidade,
                Valor = p.Valor,
                Medida = p.Medida,
                LocalSugerido = p.LocalSugerido,
                FlagComprado = p.FlagComprado
            }).ToList();
        }

        public int Id { get; set; }
        public string CodigoLista { get; set; }

        public string Nome { get; set; }

        public string Categoria { get; set; }

        public float Quantidade { get; set; }

        public float Valor { get; set; }

        public string Medida { get; set; }

        public string LocalSugerido { get; set; }

        public bool FlagComprado { get; set; }
    }
}
