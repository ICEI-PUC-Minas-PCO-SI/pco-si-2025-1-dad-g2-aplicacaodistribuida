﻿using Microsoft.AspNetCore.Mvc;
using TestDeployAPI.Model;
using TestDeployAPI.DTO;
using TestDeployAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace TestDeployAPI.Controllers
{
    [ApiController]
    [Route("usuarios")]
    public class UsuariosController : AppControllerBase
    {
        public UsuariosController(AppDBContext appDBContext, TokenService tokenService) : base(appDBContext, tokenService)
        {
        }

        [Authorize]
        [HttpPut("atualizarCadastro")]
        public IActionResult PutUsuario([FromBody] AtualizarCadastroRequestDTO request)
        {
            // Busca o ID do usuario autenticado do token
            int userId;
            try
            {
                userId = _tokenService.GetUserIdFromToken(User);
            }
            catch (Exception ex)
            {
                return Unauthorized(new MessageResponseDTO(ex.Message));
            }

            Usuarios usuario = _appDBContext.Usuarios.Find(userId);

            if (request.Email != null && request.Email != usuario.Email)
            {
                var usuarioExistente = _appDBContext.Usuarios.FirstOrDefault(u => u.Email == request.Email);
                if (usuarioExistente != null)
                {
                    return BadRequest(new MessageResponseDTO("Email já cadastrado"));
                }
                usuario.Email = request.Email;
            }

            if (request.Nome != null)
                usuario.Nome = request.Nome;

            try {
                _appDBContext.SaveChanges();
            } catch (DbUpdateException ex) {
                return BadRequest(new MessageResponseDTO("Não foi possível atualizar o cadastro: " + ex.Message));
            }

            return Ok();
        }

        [Authorize]
        [HttpDelete("deletar")]
        public IActionResult DeleteUsuario()
        {
            // Busca o ID do usuario autenticado do token
            int userId;
            try
            {
                userId = _tokenService.GetUserIdFromToken(User);
            }
            catch (Exception ex)
            {
                return Unauthorized(new MessageResponseDTO(ex.Message));
            }

            Usuarios usuario = _appDBContext.Usuarios.Find(userId);

            if (usuario == null)
                return NotFound(new MessageResponseDTO("Usuário não encontrado"));

            try
            {
                _appDBContext.Usuarios.Remove(usuario);
                _appDBContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new MessageResponseDTO("Não foi possível apagar o usuário: " + ex.Message));
            }

            return Ok();
        }
    }
}
