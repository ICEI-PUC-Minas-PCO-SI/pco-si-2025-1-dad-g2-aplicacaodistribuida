﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using TestDeployAPI.DTO;
using TestDeployAPI.Model;
using TestDeployAPI.Services;

namespace TestDeployAPI.Controllers
{
    [ApiController]
    [Route("listasCompras")]
    public class ListaComprasController : AppControllerBase
    {
        public ListaComprasController(AppDBContext appDBContext, TokenService tokenService) : base(appDBContext, tokenService)
        {
        }

        [Authorize]
        [HttpGet]
        public IActionResult GetListasUsuarioAutenticado()
        {
            // Busca o ID do usuario autenticado do token
            int userId;
            try
            {
                userId = _tokenService.GetUserIdFromToken(User);
            }
            catch (Exception ex)
            {
                return Unauthorized(new MessageResponseDTO(ex.Message));
            }

            // Busca as listas de compras do usuario autenticado
            ICollection<ListaCompras> listaCompras = _appDBContext.Usuarios.Include(u => u.ListaCompras).FirstOrDefault(u => u.Id == userId)?.ListaCompras;

            if (listaCompras.IsNullOrEmpty())
            {
                return NotFound();
            }

            return Ok(ListaComprasResponseDTO.FromModelCollection(listaCompras));
        }

        [Authorize]
        [HttpPost("criar")]
        public IActionResult PostNovaLista([FromBody] CriarListaComprasRequestDTO request)
        {
            // Busca o ID do usuario autenticado do token
            int userId;
            try
            {
                userId = _tokenService.GetUserIdFromToken(User);
            }
            catch (Exception ex)
            {
                return Unauthorized(new MessageResponseDTO(ex.Message));
            }

            ListaCompras novaLista = new ListaCompras
            {
                Nome = request.Nome,
                Descricao = request.Descricao,
                IdUsuario = userId
            };

            novaLista.Codigo = ListaComprasService.GenerateUniqueCode(_appDBContext);

            try
            {
                _appDBContext.ListaCompras.Add(novaLista);
                _appDBContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new MessageResponseDTO("Erro ao criar lista de compras: " + ex.Message));
            }

            return Ok(new { novaLista.Codigo });
        }

        [Authorize]
        [HttpPut("atualizar")]
        public IActionResult PutLista([FromBody] AtualizarListaComprasRequestDTO request)
        {
            // Busca o ID do usuario autenticado do token
            int userId;
            try
            {
                userId = _tokenService.GetUserIdFromToken(User);
            }
            catch (Exception ex)
            {
                return Unauthorized(new MessageResponseDTO(ex.Message));
            }

            ListaCompras listaCompras = _appDBContext.ListaCompras.FirstOrDefault(l => l.Codigo == request.Codigo);

            if (listaCompras == null)
                return NotFound(new MessageResponseDTO("Lista não encontrada"));
            else if (listaCompras.IdUsuario != userId)
                return Unauthorized(new MessageResponseDTO("Lista não corresponde ao usuário autenticado") );
            else if (request.Nome == listaCompras.Nome && request.Descricao == listaCompras.Descricao)
                return Ok(new MessageResponseDTO("Nenhum dado foi alterado"));

            if (!request.Nome.IsNullOrEmpty())
                listaCompras.Nome = request.Nome;
            
            if (!request.Descricao.IsNullOrEmpty())
                listaCompras.Descricao = request.Descricao;

            try
            {
                _appDBContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new MessageResponseDTO("Erro ao atualizar lista de compras: " + ex.Message));
            }

            return Ok();
        }

        [Authorize]
        [HttpDelete("deletar")]
        public IActionResult DeletarLista([FromBody] DeletarListaComprasRequestDTO request)
        {
            // Busca o ID do usuario autenticado do token
            int userId;
            try
            {
                userId = _tokenService.GetUserIdFromToken(User);
            }
            catch (Exception ex)
            {
                return Unauthorized(new { message = ex.Message });
            }

            ListaCompras listaCompras = _appDBContext.ListaCompras.FirstOrDefault(l => l.Codigo == request.Codigo);

            if (listaCompras == null)
                return NotFound(new MessageResponseDTO("Lista não encontrada"));
            else if (listaCompras.IdUsuario != userId)
                return Unauthorized(new MessageResponseDTO("Lista não corresponde ao usuário autenticado"));

            try
            {
                _appDBContext.ListaCompras.Remove(listaCompras);
                _appDBContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new MessageResponseDTO("Erro ao apagar a lista de compras: " + ex.Message));
            }

            return Ok();
        }
    }
}
