﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using TestDeployAPI.DTO;
using TestDeployAPI.Model;
using TestDeployAPI.Services;

namespace TestDeployAPI.Controllers
{
    [ApiController]
    [Route("produtos")]
    public class ProdutosController : AppControllerBase
    {
        public ProdutosController(AppDBContext appDBContext, TokenService tokenService) : base(appDBContext, tokenService)
        {
        }

        [HttpGet("{codigoLista}")]
        public IActionResult GetProdutosListaNaoAutenticado(string codigoLista)
        {
            ListaCompras listaCompras = _appDBContext.ListaCompras.Include(l => l.Produtos).FirstOrDefault(u => u.Codigo == codigoLista);

            if (listaCompras == null)
                return NotFound(new MessageResponseDTO("Lista não encontrada"));
            else if (listaCompras.Produtos.IsNullOrEmpty())
                return Unauthorized(new MessageResponseDTO("Nenhum produto encontrado"));

            return Ok(GetProdutosFromListResponseDTO.GetFromProdutosCollection(listaCompras.Produtos));
        }

        [Authorize]
        [HttpPost("criar")]
        public IActionResult PostProduto([FromBody] CriarProdutoRequestDTO request)
        {
            /* Busca o ID do usuario autenticado do token
            int userId;
            try
            {
                userId = _tokenService.GetUserIdFromToken(User);
            }
            catch (Exception ex)
            {
                return Unauthorized(new MessageResponseDTO(ex.Message));
            }*/

            ListaCompras listaCompras = _appDBContext.ListaCompras.Include(l => l.Produtos).FirstOrDefault(l => l.Codigo == request.CodigoLista);

            if (listaCompras == null)
                return NotFound(new MessageResponseDTO("Lista não encontrada"));
            //else if (listaCompras.IdUsuario != userId)
                //return Unauthorized(new MessageResponseDTO("Lista não corresponde ao usuário autenticado"));

            Produto produto = new Produto
            {
                IdListaCompras = listaCompras.Id,
                Nome = request.Nome,
                Categoria = request.Categoria,
                Quantidade = request.Quantidade,
                Valor = request.Valor,
                Medida = request.Medida,
                LocalSugerido = request.LocalSugerido,
                FlagComprado = false
            };

            try
            {
                _appDBContext.Produtos.Add(produto);
                _appDBContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new MessageResponseDTO("Erro ao criar produto: " + ex.Message));
            }

            return Ok(new CriarProdutoResponseDTO(listaCompras.Codigo, produto.Id));
        }

        [Authorize]
        [HttpPut("atualizar")]
        public IActionResult PutProduto([FromBody] AtualizarProdutoRequestDTO request)
        {
            /* Busca o ID do usuario autenticado do token
            int userId;
            try
            {
                userId = _tokenService.GetUserIdFromToken(User);
            }
            catch (Exception ex)
            {
                return Unauthorized(new MessageResponseDTO(ex.Message));
            }*/

            ListaCompras listaCompras = _appDBContext.ListaCompras.Include(l => l.Produtos).FirstOrDefault(l => l.Codigo == request.CodigoLista);

            if (listaCompras == null)
                return NotFound(new MessageResponseDTO("Lista não encontrada"));
            //else if (listaCompras.IdUsuario != userId)
                //return Unauthorized(new MessageResponseDTO("Lista não corresponde ao usuário autenticado"));

            Produto produto = listaCompras.Produtos.FirstOrDefault(p => p.Id == request.IdProduto);

            if (produto == null)
                return NotFound(new MessageResponseDTO("Produto não encontrado"));

            if (!request.Nome.IsNullOrEmpty())
                produto.Nome = request.Nome;
            if (!request.Categoria.IsNullOrEmpty())
                produto.Categoria = request.Categoria;
            if (request.Quantidade != 0)
                produto.Quantidade = request.Quantidade;
            if (request.Valor != 0)
                produto.Valor = request.Valor;
            if (!request.Medida.IsNullOrEmpty())
                produto.Medida = request.Medida;
            if (!request.LocalSugerido.IsNullOrEmpty())
                produto.LocalSugerido = request.LocalSugerido;
            if (request.Comprado != produto.FlagComprado)
                produto.FlagComprado = request.Comprado;

            try
            {
                _appDBContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new MessageResponseDTO("Erro ao atualizar produto: " + ex.Message));
            }

            return Ok();
        }

        [HttpPut("atualizarFlags")]
        public IActionResult PutProdutoComprado([FromBody] AtualizarFlagProdutoRequestDTO request)
        {

            ListaCompras listaCompras = _appDBContext.ListaCompras.Include(l => l.Produtos).FirstOrDefault(l => l.Codigo == request.CodigoLista);

            if (listaCompras == null)
                return NotFound(new MessageResponseDTO("Lista não encontrada"));

            Produto produto = listaCompras.Produtos.FirstOrDefault(p => p.Id == request.IdProduto);

            if (produto == null)
                return NotFound(new MessageResponseDTO("Produto não encontrado"));
            else if (produto.FlagComprado == request.Comprado)
                return Ok(new MessageResponseDTO("Nenhum dado foi alterado"));

            produto.FlagComprado = request.Comprado;

            try
            {
                _appDBContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new MessageResponseDTO("Erro ao atualizar produto: " + ex.Message));
            }

            return Ok();
        }

        [Authorize]
        [HttpDelete("deletar")]
        public IActionResult DeleteProduto([FromBody] DeletarProdutoRequestDTO request)
        {
            /* Busca o ID do usuario autenticado do token
            int userId;
            try
            {
                userId = _tokenService.GetUserIdFromToken(User);
            }
            catch (Exception ex)
            {
                return Unauthorized(new MessageResponseDTO(ex.Message));
            }*/

            ListaCompras listaCompras = _appDBContext.ListaCompras.Include(l => l.Produtos).FirstOrDefault(l => l.Codigo == request.CodigoLista);

            if (listaCompras == null)
                return NotFound(new MessageResponseDTO("Lista não encontrada"));
            //else if (listaCompras.IdUsuario != userId)
                //return Unauthorized(new MessageResponseDTO("Lista não corresponde ao usuário autenticado"));

            Produto produto = listaCompras.Produtos.FirstOrDefault(p => p.Id == request.IdProduto);

            if (produto == null)
                return NotFound(new MessageResponseDTO("Produto não encontrado"));

            try
            {
                _appDBContext.Produtos.Remove(produto);
                _appDBContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new MessageResponseDTO("Erro ao deletar produto: " + ex.Message));
            }

            return Ok();
        }
    }
}
