﻿using Microsoft.AspNetCore.Mvc;
using TestDeployAPI.Model;
using TestDeployAPI.Services;

namespace TestDeployAPI.Controllers
{
    public class AppControllerBase : ControllerBase
    {
        protected readonly AppDBContext _appDBContext;
        protected readonly TokenService _tokenService;

        public AppControllerBase(AppDBContext appDBContext, TokenService tokenService)
        {
            _appDBContext = appDBContext;
            _tokenService = tokenService;
        }
    }
}
