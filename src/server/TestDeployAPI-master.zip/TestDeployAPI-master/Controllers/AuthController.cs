﻿using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TestDeployAPI.DTO;
using TestDeployAPI.Model;
using TestDeployAPI.Services;

namespace TestDeployAPI.Controllers
{
    [ApiController]
    [Route("auth")]
    public class AuthController : AppControllerBase
    {
        public AuthController(AppDBContext appDBContext, TokenService tokenService) : base(appDBContext, tokenService)
        {
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequestDTO request)
        {
            Usuarios usuario = UsuariosService.GetUserFromEmailAndPassword(_appDBContext, request.Email, request.Senha);

            if (usuario == null)
            {
                return Unauthorized(new MessageResponseDTO("Credenciais inválidas"));
            }

            var token = _tokenService.GenerateToken(usuario);

            return Ok(new LoginResponseDTO(token));
        }

        [HttpPost("registro")]
        public IActionResult Registro([FromBody] RegisterRequestDTO request)
        {

            Usuarios novoUsuario = new Usuarios { Nome = request.Nome, Email = request.Email, Senha = request.Senha };

            string err = UsuariosService.RegisterUser(_appDBContext, novoUsuario);

            if (err != String.Empty)
            {
                return BadRequest(new MessageResponseDTO(err));
            }

            var token = _tokenService.GenerateToken(novoUsuario);

            return Ok(new LoginResponseDTO(token));
        }
    }
}
